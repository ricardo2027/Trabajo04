class Equipo:
    def __init__(self,nombre_equi,nro_jugadores,nro_medicos,capital,nom_DT):
        self.nombre_equi = nombre_equi
        self.nro_jugadores = nro_jugadores
        self.nro_medicos = nro_medicos
        self.capital = capital
        self.nom_DT = nom_DT

    def setNombre_DT(self,nombre_DT):
        self.nombre_DT = nombre_DT

    def getNombre_equi(self):
        return self.nombre_equi


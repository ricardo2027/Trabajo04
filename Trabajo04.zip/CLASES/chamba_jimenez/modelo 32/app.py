import equipo
import futbolista
import os


Nombre = os.sys.argv[1]
Salario = os.sys.argv[2]
Nombre_equipo = os.sys.argv[3]

F1 = futbolista.Futbolista(Nombre,equipo,120,Salario,36)
E1 = equipo.Equipo(Nombre_equipo,60,30,4500,"Paolo")

k = F1.celebrar(E1.getNombre_equi())
print(k)
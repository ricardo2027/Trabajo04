class Futbolista:
    def __init__(self,nombre,equipo,nro_goles,salario,edad):
        self.nombre = nombre
        self.equipo = equipo
        self.edad = edad
        self.salario = salario
        self.nro_goles = nro_goles

    def setNombre(self,nombre):
        self.nombre = nombre

    def getEquipo(self):
        return self.equipo

    def celebrar(self,equipo):
        msg = "El futbolista {} del equipo {} tiene un salario {}"
        return msg.format(self.nombre,equipo,self.salario)

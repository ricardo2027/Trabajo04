import circo
import payaso
import os
nombreP1 = os.sys.argv[1]
nombreC1 = os.sys.argv[2]
nro_asientos = os.sys.argv[3]
especialidad = os.sys.argv[4]

P1 = payaso.Payaso(nombreP1,especialidad,21,"M",1365489)
C1 = circo.Circo(18,20,150,nro_asientos,nombreC1)

g = P1.entretener(C1.getNombre())
print(g)
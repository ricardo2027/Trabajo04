class Circo:
    def __init__(self,nro_payaso,nro_malabarista,capacidad,nro_asientos,nombre):
        self.nombre = nombre
        self.nro_asientos = nro_asientos
        self.nro_malabarista = nro_malabarista
        self.nro_payaso = nro_payaso
        self.capacidad = capacidad

    def setNro_asientos(self,nro_asientos):
        self.nro_asientos = 215

    def getNombre(self):
        return self.nombre

    def setCapacidad(self,capacidad):
        self.capacidad = 260
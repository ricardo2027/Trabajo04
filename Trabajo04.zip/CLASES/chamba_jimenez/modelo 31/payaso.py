class Payaso:
    def __init__(self,nombre,especialidad,edad,sexo,nro_dni):
        self.nombre = nombre
        self.especialidad = especialidad
        self.edad = edad
        self.sexo = sexo
        self.nro_dni = nro_dni

    def setEspecialidad(self,especialidad):
        self.especialidad = "Malabarista"

    def getNro_dni(self):
        return self.nro_dni

    def entretener(self,circo):
        msg = "El payaso de nombre {} y nro_dni {} trabaja en el circo {}"
        return msg.format(self.nombre, self.nro_dni,circo)

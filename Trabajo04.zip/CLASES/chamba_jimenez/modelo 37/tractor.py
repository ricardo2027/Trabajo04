class Tractor:
    def __init__(self,marca,masa,nro_botones,nro_asientos,nro_placa):
        self.masa = masa
        self.marca = marca
        self.nro_asientos = nro_asientos
        self.nro_botones = nro_botones
        self.nro_placa = nro_placa

    def setNro_placa(self,nro_placa):
        self.nro_placa = nro_placa

    def getMarca(self):
        return self.marca

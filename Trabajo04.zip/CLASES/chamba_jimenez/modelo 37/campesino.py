class Campesino:
    def __init__(self,gdo_estudio,nombre,sexo,peso,edad):
        self.nombre = nombre
        self.sexo = sexo
        self.peso = peso
        self.edad = edad
        self.gdo_estudio = gdo_estudio

    def setEdad(self,edad):
        self.edad = edad

    def getNombre(self):
        return self.nombre

    def cosechar(self,tractor):
        msg = "El campesino {} cosecha mejor con el tractor de marca {}"
        return msg.format(self.nombre,tractor)

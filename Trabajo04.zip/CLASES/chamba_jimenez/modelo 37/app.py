import campesino
import tractor
import os

Nro_placa = os.sys.argv[1]
Nombre = os.sys.argv[2]
Marca = os.sys.argv[3]

C1 = campesino.Campesino("Secundaria",Nombre,"M",94,36)
T1 = tractor.Tractor(Marca,170,10,6,Nro_placa)

G=C1.cosechar(T1.getMarca())
print(G)
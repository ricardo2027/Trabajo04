class Zoologico:
    def __init__(self,nombre,nro_entradas,capacidad,nro_animales,nro_tiendas):
        self.nombre = nombre
        self.nro_entradas = nro_entradas
        self.nro_animales = nro_animales
        self.nro_tiendas = nro_tiendas
        self.capacidad = capacidad

    def setCapacidad(self,capacidad):
        self.capacidad = capacidad

    def getNombre(self):
        return self.nombre

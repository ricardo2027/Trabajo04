class Animales:
    def __init__(self,masa,tamano,clase,nro_patas,nro_dientes):
        self.masa = masa
        self.tamano = tamano
        self.nro_dientes = nro_dientes
        self.nro_patas = nro_patas
        self.clase = clase

    def setTamano(self,tamano):
        self.tamano = tamano

    def getClase(self):
        return self.clase

    def comer(self,zoologico):
        msg = "El animal de la clase {} mide {} y esta en el zoologico {}"
        return msg.format(self.clase,self.tamano,zoologico)

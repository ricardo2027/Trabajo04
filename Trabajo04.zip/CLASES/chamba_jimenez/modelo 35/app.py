import animales
import zoologico
import os

masa = os.sys.argv[1]
Clase = os.sys.argv[2]
tamano = os.sys.argv[5]
Nro_entradas = os.sys.argv[3]
Nombre = os.sys.argv[4]

A1 = animales.Animales(masa,tamano,Clase,4,30)
Z1 = zoologico.Zoologico(Nombre,Nro_entradas,300,60,45)

K = A1.comer(Z1.getNombre())
print(K)
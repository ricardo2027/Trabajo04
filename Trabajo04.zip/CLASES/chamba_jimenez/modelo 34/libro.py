class Libro:
    def __init__(self,masa,mat_tapa,autor,editorial,nro_hojas):
        self.masa = masa
        self.mat_tapa = mat_tapa
        self.autor = autor
        self.editorial = editorial
        self.nro_hojas = nro_hojas

    def setAutor(self,autor):
        self.autor = autor

    def getMat_tapa(self):
        return self.mat_tapa

    def leer(self,biblioteca):
        msg = "El libro del autor {} y de tapa {} se encuentra en la biblioteca {}"
        return msg.format(self.autor,self.mat_tapa,biblioteca)

import biblioteca
import libro
import os

Autor1 = os.sys.argv[1]
Mat_tapa = os.sys.argv[2]
Nro_libros = os.sys.argv[3]
Nombre = os.sys.argv[4]

L1 = libro.Libro(12,Mat_tapa,Autor1,"Corefo",160)
B1 = biblioteca.Biblioteca(Nro_libros,Nombre,60,20,"Madera")

N = L1.leer(B1.getNombre())
print(N)
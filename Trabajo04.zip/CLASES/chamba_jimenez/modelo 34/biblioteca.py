class Biblioteca:
    def __init__(self,nro_libros,nombre,nro_mesas,nro_computadoras,mat_mesa):
        self.nombre = nombre
        self.nro_computadoras = nro_computadoras
        self.nro_libros = nro_libros
        self.nro_mesas = nro_mesas
        self.mat_mesa = mat_mesa

    def setNro_libros(self,raza):
        self.raza = raza

    def getNombre(self):
        return self.nombre

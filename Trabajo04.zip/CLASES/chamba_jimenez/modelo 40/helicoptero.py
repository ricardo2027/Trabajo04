class Helicoptero:
    def __init__(self,nro_helices,altura_max,vel_max,masa,uso):
        self.nro_helices = nro_helices
        self.altura_max = altura_max
        self.vel_max = vel_max
        self.masa = masa
        self.uso = uso

    def setNro_helices(self,nro_helices):
        self.nro_helices = nro_helices

    def getUso(self):
        return self.uso
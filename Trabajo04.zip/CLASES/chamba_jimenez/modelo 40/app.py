import aviador
import helicoptero
import os

Raza = os.sys.argv[1]
Nro_helices = os.sys.argv[2]
Uso = os.sys.argv[3]
Pais_origen = os.sys.argv[4]
Masa = os.sys.argv[5]

A1 = aviador.Aviador(Raza,Pais_origen,12356476,Masa,"Acrobatico")
H1 = helicoptero.Helicoptero(Nro_helices,260,120,9000,Uso)

I = A1.Pilotear(H1.getUso())
print(I)
class Aviador:
    def __init__(self,raza,pais_origen,nro_dni,masa,tipo):
        self.raza = raza
        self.pais_origen = pais_origen
        self.nro_dni = nro_dni
        self.masa = masa
        self.tipo = tipo

    def setRaza(self,raza):
        self.raza = raza

    def getTipo(self):
        return self.tipo

    def Pilotear(self,helicoptero):
        msg = "El aviador de peso {}kg. representa a {} en los juegos Panamericanos con su helicoptero de uso {} "
        return msg.format(self.masa,self.pais_origen,helicoptero)
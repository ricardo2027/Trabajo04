import audifonos
import musica
import os

diseno = os.sys.argv[1]
tipo_sonido = os.sys.argv[2]
artista = os.sys.argv[3]

A1 = audifonos.Audifonos(32,"Azul","Inalambrico",diseno,tipo_sonido)
M1 = musica.Musica(185,"21","Los iracundos","Rock",2002)

j=A1.escuchar_musica(M1.getAlbum())
print(j)
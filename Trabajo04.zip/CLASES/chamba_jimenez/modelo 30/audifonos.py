class Audifonos:
    def __init__(self,masa,color,tipo_conexion,diseno,tipo_sonido):
        self.masa = masa
        self.color = color
        self.tipo_conexion = tipo_conexion
        self.diseno = diseno
        self.tipo_sonido = tipo_sonido

    def setColor(self,color):
        self.color = "Azul"

    def getTipo_conexion(self):
        return self.tipo_conexion

    def escuchar_musica(self,musica):
        msg = "En esos audifonos de color {} de conexion {} es del album {} "
        return msg.format(self.color,self.diseno,musica)

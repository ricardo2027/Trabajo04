class Musica:
    def __init__(self,duracion,album,artista,genero,ano_creacion):
        self.duracion = duracion
        self.album = album
        self.artista = artista
        self.genero = genero
        self.ano_creacion = ano_creacion

    def setDuracion(self,duracion):
        self.duracion = 185

    def getAlbum(self):
        return self.album

    def setGenero(self,genero):
        self.genero = "Rock"
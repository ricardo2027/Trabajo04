class Moto:
    def __init__(self,marca,masa,tipo_motor,capacidad,tipo):
        self.marca=marca
        self.masa=masa
        self.tipo=tipo
        self.tipo_motor=tipo_motor
        self.capacidad=capacidad

    def setMasa(self,masa):
        self.masa=masa

    def getMarca(self):
        return self.marca


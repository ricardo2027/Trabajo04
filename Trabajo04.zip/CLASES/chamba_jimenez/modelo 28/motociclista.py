class Motociclista:
    def __init__(self,grupo,tipo_sangre,talla,peso,carreras_ganadas):
        self.grupo=grupo
        self.tipo_sangre=tipo_sangre
        self.talla=talla
        self.peso=peso
        self.carreras_ganadas=carreras_ganadas


    def setTalla(self,talla):
        self.talla=talla

    def getGrupo(self):
        return self.grupo

    def alquilar(self,moto):
        msg="Juan de peso {} kg. conduce la moto {} y ha ganado {} carreras "
        return msg.format(self.peso,moto,self.carreras_ganadas)


import motociclista
import moto
import os

peso= os.sys.argv[1]
marca= os.sys.argv[2]
capacidad= os.sys.argv[3]

motociclista1 = motociclista.Motociclista("BMX","AB",185,peso,20)
moto1 = moto.Moto(marca,150,"Hibrido",capacidad,"Scooper")

t=motociclista1.alquilar(moto1.getMarca())
print(t)
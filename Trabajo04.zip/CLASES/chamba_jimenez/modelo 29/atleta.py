class Atleta:
    def __init__(self,pais_repres,vel_max,talla,masa,carreras_win):
        self.masa=masa
        self.carreras_win=carreras_win
        self.talla=talla
        self.vel_max=vel_max
        self.pais_repres=pais_repres

    def setTalla(self,talla):
        self.talla=talla


    def correr(self,estadio):
        msg="El competidor Jose del pais {} va a competir en el estadio {} y ha ganado {} carreras "
        return msg.format(self.pais_repres,estadio,self.carreras_win)


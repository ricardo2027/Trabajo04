import atleta
import estadio
import os

masa1 = os.sys.argv[1]
velocidad_maxima1 = os.sys.argv[2]
carreras_win1 = os.sys.argv[3]
nro_entradas1= os.sys.argv[4]

atleta1 = atleta.Atleta("Peru",velocidad_maxima1,175,masa1,carreras_win1)
estadio1 = estadio.Estadio(2000,"Cemento",nro_entradas1,120,"Ladrillo")

h = atleta1.correr(estadio1.getNombre())
print(h)
class Estadio:
    def __init__(self,capacidad,nombre,material,nro_entradas,tipo_asientos):
        self.capacidad = capacidad
        self.nombre = nombre
        self.material = material
        self.nro_entradas = nro_entradas
        self.tipo_asientos = tipo_asientos
    def setNro_entradas(self,nro_entradas):
        self.nro_entradas = 120

    def getNombre(self):
        return self.nombre

    def setTipo_asientos(self,tipo_asientos):
        self.tipo_asientos = "Cemento"
import asesino_sueldo
import francotirador
import os

Arma = os.sys.argv[1]
Salario= os.sys.argv[2]
Nro_dni = os.sys.argv[3]
Raza = os.sys.argv[4]
Alcance = os.sys.argv[5]
Tipo_mira = os.sys.argv[6]

AS1 = asesino_sueldo.Asesino_sueldo(Arma,50,Raza,Nro_dni,Salario)
F1 = francotirador.Francotirador(40,Alcance,7,Tipo_mira,"Ajustable")

M = AS1.matar(F1.getTipo_mira())
print(M)

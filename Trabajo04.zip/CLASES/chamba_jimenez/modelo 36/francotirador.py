class Francotirador:
    def __init__(self,masa,alcance,tipo_bala,tipo_mira,tipo_silenciador):
        self.masa = masa
        self.alcance = alcance
        self.tipo_bala = tipo_bala
        self.tipo_mira = tipo_mira
        self.tipo_silenciador = tipo_silenciador

    def setAlcance(self,alcance):
        self.alcance = alcance

    def getTipo_mira(self):
        return self.tipo_mira


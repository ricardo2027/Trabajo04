class Asesino_sueldo:
    def __init__(self,arma,masa,raza,nro_dni,salario):
        self.masa = masa
        self.arma = arma
        self.raza = raza
        self.nro_dni = nro_dni
        self.salario = salario

    def setArma(self,arma):
        self.arma = arma

    def getSalario(self):
        return self.salario

    def matar(self,francotirador):
        msg = "El asesino suelo de dni {} mato a un sujeto con un {} de tipo de mira {}"
        return msg.format(self.nro_dni,self.arma,francotirador)

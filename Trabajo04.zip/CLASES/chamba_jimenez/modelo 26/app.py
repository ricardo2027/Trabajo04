import colegio
import profesor
import os

nombre_colegio=os.sys.argv[1]
nombre_profesor=os.sys.argv[2]

c1 = colegio.Colegio(50,120,"Nacional",30,nombre_colegio)
p1 = profesor.Profesor(60,nombre_profesor,650,"Contratado",45)

print("El profesor "+str(p1.getNombre())+" trabaja en el colegio "+nombre_colegio)
class Colegio:
    def __init__(self,nro_alumnos,nro_profesores,tipo,nro_aulas,nombre):
        self.nro_alumnos = nro_alumnos
        self.nro_profesores = nro_profesores
        self.tipo = tipo
        self.nro_aulas = nro_aulas
        self.nombre = nombre

    def estudiar(self):
        pass

    def getNombre(self):
        return self.nombre

    def ejercitarse(self):
        pass

class Profesor:
    def __init__(self,peso,nombre,salario,tipo,edad):
        self.peso = peso
        self.nombre = nombre
        self.salario = salario
        self.tipo = tipo
        self.edad = edad

    def escuchar(self):
        pass

    def ensenar(self):
        return self.nombre+"esta ensenando en el colegio"+self.colegio.nombre


    def getNombre(self):
        return self.nombre

#fin_class
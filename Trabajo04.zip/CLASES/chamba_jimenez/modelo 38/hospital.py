class Hospital:
    def __init__(self,nro_doctores,nro_enfermeros,nombre,nro_pisos,material):
        self.nombre = nombre
        self.nro_doctores = nro_doctores
        self.nro_enfermeros = nro_enfermeros
        self.nro_pisos = nro_pisos
        self.material = material

    def setMaterial(self,material):
        self.material = material

    def getNombre(self):
        return self.nombre
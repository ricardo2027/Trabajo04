class Doctor:
    def __init__(self,gdo_estudio,nro_dni,nro_cirugias_exitosas,masa,edad):
        self.edad = edad
        self.nro_dni = nro_dni
        self.nro_cirugias_exitosas = nro_cirugias_exitosas
        self.masa = masa
        self.gdo_estudio = gdo_estudio

    def setNro_cirugias_exitosas(self,nro_cirugias_exitosas):
        self.nro_cirugias_exitosas = nro_cirugias_exitosas

    def getNro_dni(self):
        return self.nro_dni

    def Curar(self,hospital):
        msg = "El doctor de nro dni {} ha tenido {} cirugias exitosas en el hospital {}"
        return msg.format(self.nro_dni,self.nro_cirugias_exitosas,hospital)
import hospital
import doctor
import os

Nro_dni = os.sys.argv[1]
Nro_cirugias_exitosas = os.sys.argv[2]
Nombre = os.sys.argv[3]

D1 = doctor.Doctor("Doctorado", Nro_dni ,Nro_cirugias_exitosas , 45 , 32 )
H1 = hospital.Hospital(15,20,Nombre,5,"Cemento")


L = D1.Curar(H1.getNombre())
print(L)
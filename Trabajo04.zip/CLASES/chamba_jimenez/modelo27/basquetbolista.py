class Basquetbolista:
    def __init__(self,peso,edad,nombre,nom_equipo,talla):
        self.peso = peso
        self.edad = edad
        self.nombre = nombre
        self.nom_equipo = nom_equipo
        self.talla = talla

    def setTalla(self,talla):
        self.talla = talla

    def getNombre(self):
        return self.nombre

    def jugar(self,balon):
        msg = "El jugador {} del equipo {} hizo 10ptos en su ultimo partido con el balon de color {} "
        return msg.format(self.nombre,self.nom_equipo,balon)
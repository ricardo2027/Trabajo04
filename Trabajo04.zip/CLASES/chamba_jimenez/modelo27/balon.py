class Balon:
    def __init__(self,marca,masa,diametro,material,color):
        self.color = color
        self.diametro = diametro
        self.material = material
        self.marca = marca
        self.masa = masa

    def setDiametro(self,diametro):
        self.diametro=150

    def getMarca(self):
        return self.marca

    def patear(self):
        pass

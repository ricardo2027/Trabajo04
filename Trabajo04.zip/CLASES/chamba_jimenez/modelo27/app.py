import basquetbolista
import balon
import os

nombre_basquetbolista = os.sys.argv[1]
marca_balon=os.sys.argv[2]

b1 = basquetbolista.Basquetbolista(120,47,nombre_basquetbolista,"Barcelona",190)
bal1 = balon.Balon("Rojo",60,"Caucho",marca_balon,10)

h =b1.jugar(bal1.getMarca())
print(h)


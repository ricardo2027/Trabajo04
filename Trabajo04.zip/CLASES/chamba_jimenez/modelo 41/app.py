import banco
import cajero
import os


Dinero_guardado = os.sys.argv[1]
Capacidad = os.sys.argv[2]
Nombre = os.sys.argv[3]
Salario = os.sys.argv[4]

B1 = banco.Banco(Nombre,Capacidad,50,Dinero_guardado,10)
C1 = cajero.Cajero("Ricardo",Salario,"Corredor bolsas",72,"Mestiza")

I = C1.Atender(B1.getCapacidad())
print(I)
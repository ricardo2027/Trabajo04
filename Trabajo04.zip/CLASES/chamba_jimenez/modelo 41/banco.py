class Banco:
    def __init__(self,nombre,capacidad,nro_cajeros,dinero_guardado,nro_guardias):
        self.nombre = nombre
        self.capacidad = capacidad
        self.nro_cajeros = nro_cajeros
        self.nro_guardias = nro_guardias
        self.dinero_guardado = dinero_guardado

    def setDinero_guardado(self,dinero_guardado):
        self.dinero_guardado = dinero_guardado

    def getCapacidad(self):
        return self.capacidad
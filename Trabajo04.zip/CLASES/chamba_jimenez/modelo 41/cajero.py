class Cajero:
    def __init__(self,nombre,salario,tipo,masa,raza):
        self.nombre = nombre
        self.salario = salario
        self.tipo = tipo
        self.masa = masa
        self.raza = raza

    def setSalario(self,salario):
        self.salario = salario

    def getNombre(self):
        return self.nombre

    def Atender(self,banco):
        msg = "El cajero {} atiende en el banco {} donde su salario es {} soles"
        return msg.format(self.nombre,banco,self.salario)
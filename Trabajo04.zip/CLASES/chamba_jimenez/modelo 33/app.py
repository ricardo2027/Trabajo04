import cazador
import escopeta
import os

raza = os.sys.argv[1]
tipo = os.sys.argv[2]
tipo_esco = os.sys.argv[3]

C1 = cazador.Cazador(130,tipo,183,6548792,raza)
E1 = escopeta.Escopeta(32,7,"Acero",tipo_esco,"Doble canon")

g = C1.acechar(E1.getTipo())
print(g)
class Cazador:
    def __init__(self,masa,tipo,talla,nro_dni,raza):
        self.masa = masa
        self.tipo = tipo
        self.talla = talla
        self.raza = raza
        self.nro_dni = nro_dni

    def setRaza(self,raza):
        self.raza = raza

    def getTipo(self):
        return self.tipo

    def acechar(self,escopeta):
        msg = "El cazador de raza {} usa la escopeta de tipo {} "
        return msg.format(self.raza,escopeta)

class Escopeta:
    def __init__(self,masa,capacidad_bala,material,tipo_esco,tipo_canon):
        self.masa = masa
        self.material = material
        self.capacidad_bala = capacidad_bala
        self.tipo_esco = tipo_esco
        self.tipo_canon = tipo_canon

    def setTipo_canon(self,tipo_canon):
        self.tipo_canon = tipo_canon

    def getTipo(self):
        return self.tipo_esco
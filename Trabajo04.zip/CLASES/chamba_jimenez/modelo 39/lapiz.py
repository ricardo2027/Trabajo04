class Lapiz:
    def __init__(self,color,diseno,tipo_borrador,masa,marca):
        self.color = color
        self.diseno = diseno
        self.tipo_borrador = tipo_borrador
        self.masa = masa
        self.marca = marca

    def setDiseno(self,diseno):
        self.diseno = diseno

    def getMarca(self):
        return self.marca

    def Dibujar(self,cuaderno):
        msg = "El lapiz de marca {} y masa {} se puede utilizar muy bien en el cuaderno de tipo {}"
        return msg.format(self.marca,self.masa,cuaderno)
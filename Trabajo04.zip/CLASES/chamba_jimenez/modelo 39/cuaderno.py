class Cuaderno:
    def __init__(self,nro_hojas,tipo_hojas,mat_tapa,masa,tipo):
        self.nro_hojas= nro_hojas
        self.tipo_hojas = tipo_hojas
        self.tipo = tipo
        self.masa = masa
        self.mat_tapa = mat_tapa

    def setNro_hojas(self,nro_hojas):
        self.nro_hojas = nro_hojas

    def getTipo(self):
        return self.tipo
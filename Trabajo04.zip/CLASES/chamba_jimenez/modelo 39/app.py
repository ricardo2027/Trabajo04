import lapiz
import cuaderno
import os

Diseno = os.sys.argv[1]
Marca = os.sys.argv[2]
Masa = os.sys.argv[3]
Tipo = os.sys.argv[4]

L1 = lapiz.Lapiz("Blanco",Diseno,"Rectangular",Masa,Marca)
C1 = cuaderno.Cuaderno(120,"Bond","Dura",32,Tipo)

I = L1.Dibujar(C1.getTipo())
print(I)
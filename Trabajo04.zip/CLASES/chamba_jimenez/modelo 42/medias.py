class Medias:
    def __init__(self,talla,material,diseno,masa,color):
        self.talla = talla
        self.material = material
        self.diseno = diseno
        self.masa = masa
        self.color = color

    def setColor(self,color):
        self.color = color

    def getMaterial(self):
        return self.material

    def Proteger(self,calzado):
        msg = "Las medias de material {} van bien con el calzado {}"
        return msg.format(self.material,calzado)
import medias
import calzado
import os

Material = os.sys.argv[1]
Talla = os.sys.argv[2]

M1 = medias.Medias("M",Material,"DBZ",500,"Rojo")
C1 = calzado.Calzado(Talla,"Acero","Alta",600,"Marvel")

I = M1.Proteger(C1.getTalla())
print(I)
class Calzado:
    def __init__(self,talla,tipo_puntera,tipo_bota,masa,diseno):
        self.talla = talla
        self.tipo_bota = tipo_bota
        self.tipo_puntera = tipo_puntera
        self.masa = masa
        self.diseno = diseno

    def setDiseno(self,diseno):
        self.diseno = diseno

    def getTalla(self):
        return self.talla
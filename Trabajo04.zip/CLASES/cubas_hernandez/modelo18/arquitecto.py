class Arquitecto:
    def __init__(self,nombre,pais,edad,gmail,celular):
        self.nombre=nombre
        self.pais=pais
        self.edad=edad
        self.gmail=gmail
        self.celular=celular
    def setGnail(self,gmail):
        self.gmail=gmail
    def getNombre(self):
        return self.nombre
    def disenar(self,casa):
        msg="EL arquetecto {} con  {} de edad con numero de celualar {} realizara un plano de una casa con estilo codorico  "
        return msg.format(self.nombre,self.edad,self.celular)

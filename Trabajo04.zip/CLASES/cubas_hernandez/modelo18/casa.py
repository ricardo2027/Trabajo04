class Casa:
    def __init__(self,pisos,estilo,numero,habitacion,telefono):
        self.pisos=pisos
        self.estilo=estilo
        self.habitacion=habitacion
        self.numero=numero
        self.telefono=telefono
    def setTeleofono(self,telefono):
        self.telefono=987123456
    def getEstilo(self):
        return self.estilo
    def vivir(self,estilo):
        return "las de grecia y roma tienen un estilo"+ self.estilo

import arquitecto
import casa
import os
#estilo=os.sys.argv[1]
nombre=os.sys.argv[1]


casa1=casa.Casa(3,"condorico",123,12,987643567)
arquitecto1=arquitecto.Arquitecto(nombre,"pais","edad","gmail",987654322)

#hacemos la relacion de ambas clases


a=arquitecto1.disenar("codorico")
print(a)

import didujo
import papel
import os
nom=os.sys.argv[1]
nombre=os.sys.argv[2]
autor=os.sys.argv[3]

papel1=papel.Papel(20,"marca",10,"pintar",nom)
dibu=didujo.Dibujo(nombre,autor,120,3000,30)

#hacemos la relacion de ambas clases


a=dibu.vender(papel1.getNombre())
print(a)

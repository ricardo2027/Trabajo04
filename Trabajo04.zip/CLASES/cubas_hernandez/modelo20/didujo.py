class Dibujo:
    def __init__(self,nombre,autor,tmano,precio,antiguedad):
        self.nombre=nombre
        self.autor=autor
        self.tamano=tmano
        self.precio=precio
        self.antiguedad=antiguedad
    def setGamail(self,antiguedad):
        self.antiguedad=antiguedad
    def getNombre(self):
        return self.nombre
    def vender(self,papel):
        msg="EL dibujo {} fue pintado por {} en un papel especial {}   "
        return msg.format(self.nombre,self.autor,papel)

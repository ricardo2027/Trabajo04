class Papel:
    def __init__(self,tamano,marca,precio,uso,nombre):
        self.nombre=nombre
        self.marca=marca
        self.precio=precio
        self.uso=uso
        self.tamano=tamano
    def setPres(self,precio):
        self.precio=4
    def getNombre(self):
        return self.nombre
    def calcar(self,didujo):
        return "el papel de maraca"+ self.marca+ "es muy bueno para hacer dibujos"

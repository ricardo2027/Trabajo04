class   Motoniveladora:
    def __init__(self,potencia,marca,placa,pais_origen,valor):
        self.potancia=potencia
        self.marca=marca
        self.placa=placa
        self.pais_origen=pais_origen
        self.valor=valor
    def setValor(self,valor):
        self.valor=valor
    def getNombre(self):
        return self.marca
    def  potencia(self,potencia):
        return "la moto niveladora de marca"+ self.marca+ "tiene una potencia de"+ self.potancia


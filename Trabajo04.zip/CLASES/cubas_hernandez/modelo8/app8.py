import operador
import motoniveladora
import os
marca=os.sys.argv[1]
nombre=os.sys.argv[2]
maquina=os.sys.argv[3]

moto1=motoniveladora.Motoniveladora(4000,marca,12345,"japon",2000000)
opera=operador.Operador(nombre,3000,30,maquina,987654323)

#hacemos la relacion de ambas clases


a=opera.manejar(moto1.getNombre())
print(a)

class Operador:
    def __init__(self,nombre,sueldo,edad,maquina,celular):
        self.nombre=nombre
        self.maquina=maquina
        self.sueldo=sueldo
        self.edad=edad
        self.celular=celular
    def setMaquina(self,maquina):
        self.maquina=maquina
    def getNombre(self):
        return self.nombre
    def manejar(self,motoniveladora):
        msg="EL operador {} con numero de celular {} maneja la motoniveladora {}   "
        return msg.format(self.nombre,self.celular,motoniveladora)

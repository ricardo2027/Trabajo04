class Mar:
    def __init__(self,nombre,recursos,especies,rios):
        self.nombre=nombre
        self.recursos=recursos
        self.especies=especies
        self.rios=rios
    def setGamail(self,epecies):
        self.especies=especies
    def getNombre(self):
        return self.nombre
    def transportar(self,rio):
        msg="en el mar de {} desemboca el rio {} que es el segundo oceano mas abundante en recursos  {}   "
        return msg.format(self.nombre,rio,self.recursos)

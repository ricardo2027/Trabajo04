import mar
import rio
import os
nombre=os.sys.argv[1]
nombr=os.sys.argv[2]



mar1=mar.Mar(nombre,"ictiologicos","anchoveta","amazonas")
rio1=rio.Rio(nombr,"2000","arequipa","napo","efluen")
#hacemos la relacion de ambas clases


a=mar1.transportar(rio1.getNombre())
print(a)

class Rio:
    def __init__(self,nombre,longitud,naciente,afluentes,efluentes):
        self.nombre=nombre
        self.longitud=longitud
        self.naciente=naciente
        self.afluentes=afluentes
        self.efluentes=efluentes
    def setArea(self,telefono):
        self.telefono=987123456
    def getNombre(self):
        return self.nombre
    def navegar(self,nombre):
        return "e rio "+ self.nombre +"es el mas largo del mundo"

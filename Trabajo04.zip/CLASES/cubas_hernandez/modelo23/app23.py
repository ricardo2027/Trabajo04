import avion
import aeropuerto
import os
piloto=os.sys.argv[1]
empresa=os.sys.argv[2]
nombre=os.sys.argv[3]
pais=os.sys.argv[4]

avion1=avion.Avion("lan_peruvian","marca",piloto,empresa,180)
erop=aeropuerto.Aeropuerto(nombre,pais,"lan peruvian",400,"internacional")

#hacemos la relacion de ambas clases


a=avion1.volar(erop.getNombre())
print(a)

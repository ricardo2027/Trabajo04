class Avion:
    def __init__(self,nombre,marca,piloto,empresa,capacidad):
        self.nombre=nombre
        self.marca=marca
        self.piloto=piloto
        self.empresa=empresa
        self.capacidad=capacidad
    def setGamail(self,piloto):
        self.piloto=piloto
    def getNombre(self):
        return self.nombre
    def volar(self,aeropuerto):
        msg="EL avion  de la empresa {} saldra  del aeropuerto {} con destino a europa pilotado por {}  "
        return msg.format(self.nombre,aeropuerto,self.piloto)

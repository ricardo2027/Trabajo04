class Aeropuerto:
    def __init__(self,nombre,pais,empresas,aviones,categoria):
        self.nombre=nombre
        self.pais=pais
        self.empresas=empresas
        self.aviones=aviones
        self.categoria=categoria
    def setArea(self,categoria):
        self.categoria="internacional"
    def getNombre(self):
        return self.nombre
    def jugar(self,locales):
        return "el auropuerto"+ self.nombre+ "tine varias empresas trabajando"

class Equipo:
    def __init__(self,nombre,patrocinador,presidente,entrenador,telefono):
        self.nombre=nombre
        self.patrocinador=patrocinador
        self.presidente=presidente
        self.entrenador=entrenador
        self.telefono=telefono
    def setArea(self,telefono):
        self.telefono=987123456
    def getNombre(self):
        return self.nombre
    def jugar(self,locales):
        return "el equipo"+self.nombre+ "adquirido varios triunfos"

import deportista
import equipo
import os
nom=os.sys.argv[1]
nombre=os.sys.argv[2]

equipo1=equipo.Equipo(nom,"patrocinador","presidente","entrenador","telefono")
depor1=deportista.Deportista(nombre,"equipo","30","gmail","celular")

#hacemos la relacion de ambas clases


a=depor1.competir(equipo1.getNombre())
print(a)

class Deportista:
    def __init__(self,nombre,equipo,edad,gmail,celular):
        self.nombre=nombre
        self.equipo=equipo
        self.edad=edad
        self.gmail=gmail
        self.celular=celular
    def setGamail(self,gmail):
        self.gmail=gmail
    def getNombre(self):
        return self.nombre
    def competir(self,equipo):
        msg="EL deportista {} juega en el equipo de {} a su  edad de {}   "
        return msg.format(self.nombre,equipo,self.edad)

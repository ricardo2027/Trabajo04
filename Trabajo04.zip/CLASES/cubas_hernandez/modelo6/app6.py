import academia
import alumno
import os
nom=os.sys.argv[1]
nombre=os.sys.argv[2]
carrera=os.sys.argv[3]

academia1=academia.Academia(nom,"lora y lora",20,2,23456)
alumno1=alumno.Alumno(nombre,carrera,18,"aldogmail.com",9780964234)

#hacemos la relacion de ambas clases


a=alumno1.estudiar(academia1.getNombre())
print(a)

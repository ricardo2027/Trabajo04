class Academia:
    def __init__(self,nombre,ubicasion,num_profesores,locales,telefono):
        self.nombre=nombre
        self.ubicasion=ubicasion
        self.num_profesores=num_profesores
        self.locales=locales
        self.telefono=telefono
    def setArea(self,telefono):
        self.telefono=987123456
    def getNombre(self):
        return self.nombre
    def aperturar(self,locales):
        return "la academia "+ self.nombre+ "ubicada en "+ self.ubicasion+ "con locales "+ self.locales

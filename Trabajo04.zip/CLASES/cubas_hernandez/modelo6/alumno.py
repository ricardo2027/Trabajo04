class Alumno:
    def __init__(self,nombre,carrera,edad,gmail,celular):
        self.nombre=nombre
        self.carrera=carrera
        self.edad=edad
        self.gmail=gmail
        self.celular=celular
    def setGnail(self,gmail):
        self.gmail=gmail
    def getNombre(self):
        return self.nombre
    def estudiar(self,academia):
        msg="EL alumno {} con numero de celular {} esta matriculado en la cademia {} siclo 2020 I  "
        return msg.format(self.nombre,self.celular,academia)

class Agricultor:
    def __init__(self,edad,nombre,talla,peso,dni):
        self.edad=edad
        self.nombre=nombre
        self.talla=talla
        self.peso=peso
        self.dni=dni
    def setTalla(self,talla):
        self.talla=talla
    def getNombre(self):
        return self.nombre
    def trabajar(self,chacra):
        msg="EL señor {} identificado con dni numero {} tiene sembrio de {}  "
        return msg.format(self.nombre,self.dni,chacra)

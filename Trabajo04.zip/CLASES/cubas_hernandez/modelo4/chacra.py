class Chacra:
    def __init__(self,area,ubicasion,tipo_tierra,sembrio,malezas):
        self.area=area
        self.ubicasion=ubicasion
        self.tipo_tierra=tipo_tierra
        self.sembrio=sembrio
        self.malezas=malezas
    def setArea(self,area):
        self.area=400
    def getSembrio(self):
        return self.sembrio
    def montar(self,malezas):
        return "la chacra "+ "ubicada en "+ self.ubicasion+ "esta lleno de "+ self.malezas


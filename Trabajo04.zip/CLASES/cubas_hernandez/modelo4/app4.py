import agricultor
import chacra
import os
nombre=os.sys.argv[1]
dni=os.sys.argv[2]
sembrio=os.sys.argv[3]

chacra1=chacra.Chacra(1000,"norte","humus",sembrio,"cadillo")
agricultor1=agricultor.Agricultor(48,nombre,120,50,dni)

#hacemos la relacion de ambas clases


a=agricultor1.trabajar(chacra1.getSembrio())
print(a)

class Paneton:
    def __init__(self,marca,peso,masa,azucares,costo):
        self.marca=marca
        self.peso=peso
        self.masa=masa
        self.azucares=azucares
        self.costo=costo
    def setArea(self,costo):
        self.costo=costo
    def getMarca(self):
        return self.marca
    def llenar(self,costo):
        return "el poneton marca"+ self.marca+ "tiene bastantes "+ self.azucares

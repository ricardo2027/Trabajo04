import cena
import paneton
import os
nombre=os.sys.argv[1]
marca=os.sys.argv[2]


pane=paneton.Paneton(marca,"5kg","4","500q","50$")
cena1=cena.Cena(nombre,"donofrio","pavo al horno","sapatos carteras","pesebre")
#hacemos la relacion de ambas clases


a=cena1.compartir(pane.getMarca())
print(a)

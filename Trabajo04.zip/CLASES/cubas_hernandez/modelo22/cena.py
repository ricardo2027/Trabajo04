class Cena:
    def __init__(self,nombre,paneton,preparativos,regalos,decoracion):
        self.nombre=nombre
        self.preparativos=preparativos
        self.regalos=regalos
        self.paneton=paneton
        self.decoracion=decoracion
    def setGamail(self,paneton):
        self.paneton=paneton
    def getNombre(self):
        return self.nombre
    def compartir(self,paneton):
        msg="en la cena {} se reuniran familias reagalaran {} pero tambien iran a disfrutar del paneton {}   "
        return msg.format(self.nombre,self.regalos,paneton)

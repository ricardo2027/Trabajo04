import trucha
import pisina
import os

nombre=os.sys.argv[1]


trucha1=trucha.Trucha(1,"3 meses","2 toneladas","10 kilo","antolino")
pisi1=pisina.Pisina(nombre,"dos hectareas","dos toneladas","felipe")
#hacemos la relacion de ambas clases


a=pisi1.criar(trucha1.getNombre())
print(a)

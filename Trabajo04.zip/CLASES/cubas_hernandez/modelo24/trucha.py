class Trucha:
    def __init__(self,peso,edad,cantidad,costo,dueno):
        self.peso=peso
        self.edad=edad
        self.cantidad=cantidad
        self.costo=costo
        self.dueno=dueno
    def setArea(self,cantidad):
        self.cantidad=987123456
    def getNombre(self):
        return self.cantidad
    def crecer(self,costo):
        return "la trucha se vende al precio de"+ self.costo

class Pisina:
    def __init__(self,nombre,area,cantidad,dueno):
        self.nombre=nombre
        self.area=area
        self.cantidad=cantidad
        self.dueno=dueno

    def setGamail(self,dueno):
        self.dueno=dueno
    def getNombre(self):
        return self.nombre
    def criar(self,trucha):
        msg="en la psigranja {} se cria  {} de trucha "
        return msg.format(self.nombre,trucha)

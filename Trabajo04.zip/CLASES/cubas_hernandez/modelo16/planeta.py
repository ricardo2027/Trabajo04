class Planeta:
    def __init__(self,nombre,radio,masa,temperatura,velocidad):
        self.nombre=nombre
        self.radio=radio
        self.temperatura=temperatura
        self.masa=masa
        self.velocidad=velocidad
    def setVelocidad(self,velocidad):
        self.velocidad=velocidad
    def getNombre(self):
        return self.nombre
    def traslada(self,masa):
        return "el planeta de marte tiene una masa de"+ self.masa

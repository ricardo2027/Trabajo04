class Robot:
    def __init__(self,nombre,peso,edad,masa,empresa):
        self.nombre=nombre
        self.peso=peso
        self.edad=edad
        self.masa=masa
        self.empresa=empresa
    def setPeso(self,peso):
        self.peso=peso
    def getNombre(self):
        return self.nombre
    def explorar(self,planeta):
        msg="EL robot {} creado {} esta hacindo un exploracion en planeta {} desde  2012  hasta la fecha ha enviado muchas imagenes reveladoras "
        return msg.format(self.nombre,self.empresa,planeta)

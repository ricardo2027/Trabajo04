import planeta
import robot
import os
nom=os.sys.argv[1]
empresa=os.sys.argv[2]
nombre=os.sys.argv[3]

robo1=robot.Robot(nom,"peso",4,10000,empresa)
pla1=planeta.Planeta(nombre,345,1234567,-80,"velocidad")

#hacemos la relacion de ambas clases


a=robo1.explorar(pla1.getNombre())
print(a)

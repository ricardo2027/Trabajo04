class Hospital:
    def __init__(self,nombre,ubicasion,num_doctores,camillas,categoria):
        self.nombre=nombre
        self.ubicasion=ubicasion
        self.num_doctores=num_doctores
        self.camillas=camillas
        self.categoria=categoria
    def setCategoria(self,categoria):
        self.categoria=categoria
    def getNombre(self):
        return self.nombre
    def operar(self,num_doctores):
        return "en el hospital"+ self.nombre+ "tiene un numero de doctores"+ self.num_doctores

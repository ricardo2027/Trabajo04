import doctor
import hospital
import os
nomb=os.sys.argv[1]
especialidad=os.sys.argv[2]
nombre=os.sys.argv[3]

doc1=doctor.Doctor(nomb,especialidad,30,"holagmail.com",987654322)
hos=hospital.Hospital(nombre,"piura",300,3000,"2_2")

#hacemos la relacion de ambas clases


a=doc1.recetar(hos.getNombre())
print(a)

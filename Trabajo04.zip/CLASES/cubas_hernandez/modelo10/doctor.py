class Doctor:
    def __init__(self,nombre,especialidad,edad,gmail,celular):
        self.nombre=nombre
        self.especialidad=especialidad
        self.edad=edad
        self.gmail=gmail
        self.celular=celular
    def setGnail(self,gmail):
        self.gmail=gmail
    def getNombre(self):
        return self.nombre
    def recetar(self,hospital):
        msg="EL doctor {} de  especialidad {} trabajo en hospital  {}   "
        return msg.format(self.nombre,self.especialidad,hospital)

class Pais:
    def __init__(self,nombre,ubicasion,num_poblacion,idioma,presidente):
        self.nombre=nombre
        self.ubicasion=ubicasion
        self.num_poblacion=num_poblacion
        self.idioma=idioma
        self.presidente=presidente
    def setIdioma(self,idioma):
        self.idioma=idioma
    def getNombre(self):
        return self.nombre
    def crecer(self,idioma):
        return "el pais de "+ self.nombre+ "se habla el idioma"+ self.idioma

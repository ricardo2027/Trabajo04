import pais
import presidente
import os
nom=os.sys.argv[1]

idioma=os.sys.argv[2]
nombre=os.sys.argv[3]

pres=presidente.Presidente(nom,"pais",idioma,"gmail","celular")
pais=pais.Pais(nombre,"ubicasion",40000000,"idioma","presidente")

#hacemos la relacion de ambas clases


a=pres.gobernar(pais.getNombre())
print(a)

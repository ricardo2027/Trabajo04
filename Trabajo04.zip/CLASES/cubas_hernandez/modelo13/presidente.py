class Presidente:
    def __init__(self,nombre,pais,idioma,gmail,celular):
        self.nombre=nombre
        self.pais=pais
        self.idioma=idioma
        self.gmail=gmail
        self.celular=celular
    def setGnail(self,gmail):
        self.gmail=gmail
    def getNombre(self):
        return self.nombre
    def gobernar(self,pais):
        msg=" {} es pesidente de {} esta realizando grandez cosas por su pais  "
        return msg.format(self.nombre,pais)

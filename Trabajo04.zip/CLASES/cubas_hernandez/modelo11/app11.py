import casador
import escopeta
import os
nombre=os.sys.argv[1]
talla=os.sys.argv[2]
marca=os.sys.argv[3]

casad1=casador.Casador(nombre,talla,40,"broni",923456609)
escope1=escopeta.Escopeta(20,200,marca,1000,2)

#hacemos la relacion de ambas clases


a=casad1.casar(escope1.getMarca())
print(a)

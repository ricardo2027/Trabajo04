class Casador:
    def __init__(self,nombre,talla,edad,escopeta,celular):
        self.nombre=nombre
        self.talla=talla
        self.edad=edad
        self.escopeta=escopeta
        self.celular=celular
    def setcelular(self,celular):
        self.celular=celular
    def getNombre(self):
        return self.nombre
    def casar(self,escopeta):
        msg="EL cazador {} con una estatura de  {} es un gran casador con la escopeta {}   "
        return msg.format(self.nombre,self.talla,escopeta)

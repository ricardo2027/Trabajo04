class Escopeta:
    def __init__(self,caserina,alcanse,marca,costo,peso):
        self.marca=marca
        self.alcanse=alcanse
        self.caserina=caserina
        self.costo=costo
        self.peso=peso
    def setArea(self,peso):
        self.peso=peso
    def getMarca(self):
        return self.marca
    def disparar(self,locales):
        return " la escopeta de mrca"+ self.marca+ "tiene un alcanse de"+ self.alcanse

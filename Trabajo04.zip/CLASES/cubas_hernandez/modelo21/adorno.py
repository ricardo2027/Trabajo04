class Adorno:
    def __init__(self,precio,tipo,cantidad,masa,volumen):
        self.precio=precio
        self.tipo=tipo
        self.cantidad=cantidad
        self.masa=masa
        self.volumen=volumen
    def setArea(self,volumen):
        self.volumen=23
    def getNombre(self):
        return self.tipo
    def adornar(self,tipo):
        return "en el mercado modelo encontramos bastante tipos de adorno"+ self.tipo

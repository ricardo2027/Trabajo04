import adorno
import arbol
import os
precio=os.sys.argv[1]
tipo=os.sys.argv[2]

arbo=arbol.Arbol("a",5,"navideno",12,"platico")
ador=adorno.Adorno(precio,tipo,2,3,30)

#hacemos la relacion de ambas clases


a=arbo.adornar(ador.getNombre())
print(a)

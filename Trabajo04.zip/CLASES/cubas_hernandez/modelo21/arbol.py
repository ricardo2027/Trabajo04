class Arbol:
    def __init__(self,precio,tamano,material,adorno,luces):
        self.precio=precio
        self.material=material
        self.adorno=adorno
        self.tamano=tamano
        self.luces=luces
    def setGamail(self,luces):
        self.luces=luces
    def getNombre(self):
        return self.material
    def adornar(self,adorno):
        msg="por fiestas de fin de año se venden arbolitos {} precios modicos {} adornanados con {}  "
        return msg.format(self.material,self.precio,adorno)

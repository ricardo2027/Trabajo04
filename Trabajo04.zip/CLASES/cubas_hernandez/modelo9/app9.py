import policia
import moto
import os
marca=os.sys.argv[1]
nombre=os.sys.argv[2]


moto1=moto.Moto(marca,1234355,1,200,500)
poli=policia.Policia(nombre,234566,"san juan","antidrogas",912345678)

#hacemos la relacion de ambas clases


a=poli.intervenir(moto1.getMarca())
print(a)

class Policia:
    def __init__(self,nombre,dni,comiseria,especialidad,celular):
        self.nombre=nombre
        self.dni=dni
        self.comiseria=comiseria
        self.especialidad=especialidad
        self.celular=celular
    def setGnail(self,dni):
        self.dni=dni
    def getNombre(self):
        return self.nombre
    def intervenir(self,moto):
        msg="EL policia {} con numero de dni {} ha realizado una intervencion con la moto {} logrando interceptar al malechor "
        return msg.format(self.nombre,self.celular,moto)

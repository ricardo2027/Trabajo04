class Moto:
    def __init__(self,marca,placa,capacidad,velocidad_maxima,potencia):
        self.marca=marca
        self.placa=placa
        self.capacidad=capacidad
        self.veloxidad_maxima=velocidad_maxima
        self.potencia=potencia
    def setPotencia(self,potencia):
        self.potencia=potencia
    def getMarca(self):
        return self.marca
    def trasladar(self,locales):
        return "la moto "+ self.marca+ "tiene una velociadad maxima"+self.veloxidad_maxima

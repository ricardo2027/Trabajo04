import artefacto
import tienda
import os
marca=os.sys.argv[1]
nombre=os.sys.argv[2]

arte1=artefacto.Artefacto(marca,50,1000,234,"esmeralda")
tien=tienda.Tienda(nombre,"capital","distri","microndas",9876542343)

#hacemos la relacion de ambas clases


a=arte1.calentar(tien.getNombre())
print(a)

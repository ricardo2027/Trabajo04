class Tienda:
    def __init__(self,nombre,capital,distri,artefacto,telefono):
        self.nombre=nombre
        self.capital=capital
        self.distri=distri
        self.artefacto=artefacto
        self.telefono=telefono
    def setArea(self,telefono):
        self.telefono=987123456
    def getNombre(self):
        return self.nombre
    def aperturar(self,nombre):
        return "la tienda"+ "es la mas grande del lugar"

class Artefacto:
    def __init__(self,marca,peso,costo,codigo,tienda):
        self.marca=marca
        self.peso=peso
        self.costo=costo
        self.codigo=codigo
        self.tienda=tienda
    def setCode(self,codigo):
        self.codigo=codigo
    def getNombre(self):
        return self.marca
    def calentar(self,artefacto):
        msg="un horno microondas marca {} con un codigo en  {} se esta vendiendo en la tienda {}   "
        return msg.format(self.marca,self.codigo,artefacto)

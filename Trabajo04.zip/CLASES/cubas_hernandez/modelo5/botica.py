class   Botica:
    def __init__(self,nombre,ruc,num_farmaceuticos,num_sucursales,convenios):
        self.nombre=nombre
        self.ruc=ruc
        self.num_farceu=num_farmaceuticos
        self.sucur=num_sucursales
        self.convenios=convenios
    def setRuc(self,ruc):
        self.ruc=ruc
    def getNombre(self):
        return self.nombre
    def vender(self,laboratorio):
        msg="la  botica {} con surcursales en {} tiene conenio con el labotatorio {}  "
        return msg.format(self.nombre,self.sucur,laboratorio)

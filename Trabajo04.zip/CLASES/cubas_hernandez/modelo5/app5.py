import botica
import laboratorio
import os
nom=os.sys.argv[1]
convenios=os.sys.argv[3]
nombre=os.sys.argv[2]

boti=botica.Botica(nom,12345,4,"peru",convenios)
labora=laboratorio.Laboratorio(nombre,200,"personas",12345,"alemania")

#hacemos la relacion de ambas clases


a=boti.vender(labora.getNombre())
print(a)

class Laboratorio:
    def __init__(self,nombre,equipos,tipo_laboratorio,ruc,ubicasion):
        self.nombre=nombre
        self.equipos=equipos
        self.tipo_laboratorio=tipo_laboratorio
        self.ruc=ruc
        self.ubicasion=ubicasion
    def setTipo(self,tipo):
        self.tipo="plantas"
    def getNombre(self):
        return self.nombre
    def elaborar(self,equipos):
        return "el laboratorio "+ self.nombre+ "ubicada en "+ self.ubicasion+ "tiene equipos "+ self.equipos

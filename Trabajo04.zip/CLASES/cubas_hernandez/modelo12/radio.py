class Radio:
    def __init__(self,nombre,ubicasion,locutores,frecuencias,potencia):
        self.nombre=nombre
        self.ubicasion=ubicasion
        self.locutores=locutores
        self.frecuencias=frecuencias
        self.potencia=potencia
    def setUbicasion(self,ubicasion):
        self.ubicasion=ubicasion
    def getNombre(self):
        return self.nombre
    def programar(self,locales):
        return "la radio "+ self.nombre+ "tiene bastante locutores"+ self.locutores

class Locutor:
    def __init__(self,nombre,radio,edad,gmail,celular):
        self.nombre=nombre
        self.radio=radio
        self.edad=edad
        self.gmail=gmail
        self.celular=celular
    def setGnail(self,gmail):
        self.gmail=gmail
    def getNombre(self):
        return self.nombre
    def locutar(self,radio):
        msg="EL locutor {} con numero de celular {} trabaja en la radio {}   "
        return msg.format(self.nombre,self.celular,radio)



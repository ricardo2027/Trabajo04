import locutor
import radio
import os
nom=os.sys.argv[1]
nombre=os.sys.argv[2]


radi=radio.Radio(nom,"lima",12,"107.1","1000hs")
locutor1=locutor.Locutor(nombre,"anonimo",28,"gmail",986543322)

#hacemos la relacion de ambas clases


a=locutor1.locutar(radi.getNombre())
print(a)

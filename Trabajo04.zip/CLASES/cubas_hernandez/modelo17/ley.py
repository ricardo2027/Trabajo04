class Ley:
    def __init__(self,nombre,fisico,rama,aplicasion,origen):
        self.nombre=nombre
        self.fisico=fisico
        self.rama=rama
        self.aplicasion=aplicasion
        self.origen=origen
    def setOrigen(self,origen):
        self.origen=origen
    def getNombre(self):
        return self.nombre
    def modelar(self,fisico):
        return  "la ley de la inercia es dado por el"+ self.fisico

class Fisico:
    def __init__(self,nombre,carrera,edad,ley,celular):
        self.nombre=nombre
        self.carrera=carrera
        self.edad=edad
        self.ley=ley
        self.celular=celular
    def setCelular(self,celular):
        self.celular=celular
    def getNombre(self):
        return self.nombre
    def inventar(self,ley):
        msg="EL fisico {} planteo la teoria  {}   "
        return msg.format(self.nombre,ley)

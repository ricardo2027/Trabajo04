import fisico
import ley
import os
nom=os.sys.argv[1]
nombre=os.sys.argv[2]

fis=fisico.Fisico(nom,"carrera2","edad","ley","celular")
ley1=ley.Ley(nombre,"fisico","fisica",234,"alemania")

#hacemos la relacion de ambas clases


a=fis.inventar(ley1.getNombre())
print(a)

class Cheff:
    def __init__(self,nombre,dni,edad,sueldo,tiempo_trabajo):
        self.nombre=nombre
        self.sueldo=sueldo
        self.dni=dni
        self.edad=edad
        self.tiempo_trabajo=tiempo_trabajo
    def setGmail(self,dni):
        self.dni=dni
    def getNombre(self):
        return self.nombre
    def cosinar(self,restaurant):
        msg="EL cheff {} con un sueldo {} trabajo en restaurant {}   "
        return msg.format(self.nombre,self.sueldo,restaurant)

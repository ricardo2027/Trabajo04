import cheff
import restaurant
import os
nom=os.sys.argv[1]
nombre=os.sys.argv[2]
platos=os.sys.argv[3]

cheff1=cheff.Cheff(nom,123456,28,3000,6)
restaurant1=restaurant.Restaurante(nombre,12345,4,platos,98653)

#hacemos la relacion de ambas clases


a=cheff1.cosinar(restaurant1.getNombre())
print(a)

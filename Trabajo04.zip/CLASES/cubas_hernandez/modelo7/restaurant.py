class Restaurante:
    def __init__(self,nombre,ruc,num_cheff,platos,telefono):
        self.nombre=nombre
        self.ruc=ruc
        self.num_cheff=num_cheff
        self.platos=platos
        self.telefono=telefono
    def setArea(self,ruc):
        self.ruc=ruc
    def getNombre(self):
        return self.nombre
    def ofrecer(self,locales):
        return "la academia "+ self.nombre+ "ubicada en "+ self.ubicasion+ "con locales "+ self.locales

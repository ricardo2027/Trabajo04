import fabrica
import volquete
import os
capacidad=os.sys.argv[1]
marca=os.sys.argv[2]
fabri=os.sys.argv[3]
nombre=os.sys.argv[4]


v1=volquete.Volquete(capacidad,marca,fabri,123,4000)
f1=fabrica.Fabrica(nombre,1234,25,100,"ensamblaje")
a=f1.ensamblar(v1.getNombre())
print(a)


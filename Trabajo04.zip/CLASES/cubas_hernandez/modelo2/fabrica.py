#crearemos la clase fabrica

class Fabrica:
    def __init__(self,nombre,ruc,num_maquinaria,num_trabajadores,tipo_producion):
        self.nombre=nombre
        self.ruc=ruc
        self.num_maquinaria=num_maquinaria
        self.num_trabajadores=num_trabajadores
        self.tipo_producion=tipo_producion
    def setRuc(self,ruc):
        self.ruc=ruc
    def getNombre(self):
        return self.nombre
    def ensamblar(self,volquete):
        msg="la fabrica {} con numero de ruc {} emsamblar las piesas del un volquqete marca {}  "
        return msg.format(self.nombre,self.ruc,volquete)




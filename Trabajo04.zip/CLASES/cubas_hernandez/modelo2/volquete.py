#crearemos la clase volquete
class Volquete:
    def __init__(self,capacidad,marca,fabrica,num_plca,potencia):
        self.capacidad=capacidad
        self.marca=marca
        self.fabrica=fabrica
        self.num_plca=num_plca
        self.potencia=potencia

    def setnum_hab(self,num_placa):
        self.num_placa=123456
    def getNombre(self):
        return self.marca

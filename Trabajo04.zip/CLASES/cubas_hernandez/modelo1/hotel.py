class Hotel:
    def __init__(self,pisos,nombre,valor_habi,num_hab,ruc):
        self.pisos=pisos
        self.nombre=nombre
        self.valor_habi=valor_habi
        self.num_hab=num_hab
        self.ruc=ruc
    def setnum_hab(self,num_hab):
        self.num_hab=40
    def getNombre(self):
        return self.nombre
    #def abrir(self,valor_habitacion):
        #python modelo1/app1.py 40 simon americas 140 30

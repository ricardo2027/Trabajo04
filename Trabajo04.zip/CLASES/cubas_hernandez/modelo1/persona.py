#crearemos la clase persona

class Persona:
    def __init__(self,edad,nombre,talla,peso,dni):
        self.edad=edad
        self.nombre=nombre
        self.talla=talla
        self.peso=peso
        self.dni=dni
    def setTalla(self,talla):
        self.talla=talla
    def getNombre(self):
        return self.nombre
    def alquilar(self,hotel):
        msg="EL señor {} identificado con dni numero {} va estar hospedado en el hotel {}  "
        return msg.format(self.nombre,self.dni,hotel)





import persona as per
import hotel as  hot
import os
edad=os.sys.argv[1]
nombre=os.sys.argv[2]
nom=os.sys.argv[3]
valor=os.sys.argv[4]
numero=os.sys.argv[5]

persona1=per.Persona(edad,nombre,1.60,80,12345678)
h1=hot.Hotel(10,nom,valor,numero,123445)
#hacemos la relacion de ambas clases


a=persona1.alquilar(h1.getNombre())
print(a)


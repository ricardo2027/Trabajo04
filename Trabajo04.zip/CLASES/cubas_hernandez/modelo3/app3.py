import postulante
import universidad
import os
nombre=os.sys.argv[1]
post=os.sys.argv[2]
carrera=os.sys.argv[3]

uni=universidad.Universidad(nombre,1000,20,9876,50000)
post=postulante.Postulante(post,carrera,123456,20,98765432)
#hacemos la relacion de ambas clases


a=post.estudiar(uni.getNombre())
print(a)

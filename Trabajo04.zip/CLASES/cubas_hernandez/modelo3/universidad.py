class Universidad:
    def __init__(self,nombre,num_carreras,num_vacantes,telefono,num_postulantes):
        self.nombre=nombre
        self.num_carreras=num_carreras
        self.nuum_vacantes=num_vacantes
        self.telefono=telefono
        self.num_postualntes=num_postulantes
    def setnum_tel(self,telefono):
        self.num_tel=97809623
    def getNombre(self):
        return self.nombre


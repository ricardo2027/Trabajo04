class Postulante:
    def __init__(self,nombre,carrera,dni,edad,celular):
        self.nombre=nombre
        self.carrera=carrera
        self.dni=dni
        self.edad=edad
        self.celular=celular
    def setTalla(self,celular):
        self.celular=celular
    def getNombre(self):
        return self.nombre
    def estudiar(self,universidad):
        msg="EL postulante {} postula a la carrera de  {} en la universidad  {}  "
        return msg.format(self.nombre,self.carrera,universidad)

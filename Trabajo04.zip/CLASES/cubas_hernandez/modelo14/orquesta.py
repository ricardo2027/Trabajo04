class Orquesta:
    def __init__(self,nombre,vocalista,num_musicos,origen,telefono):
        self.nombre=nombre
        self.vocalista=vocalista
        self.num_musicos=num_musicos
        self.origen=origen
        self.telefono=telefono
    def setTelefono(self,telefono):
        self.telefono=987123456
    def getNombre(self):
        return self.nombre
    def tocar(self,nombre):
        return "la orqueta "+ self.nombre+ "es famosa"

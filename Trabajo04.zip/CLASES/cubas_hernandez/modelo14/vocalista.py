class Vocalista:
    def __init__(self,nombre,musicas,orquesta,gmail,celular):
        self.nombre=nombre
        self.musicas=musicas
        self.orqueta=orquesta
        self.gmail=gmail
        self.celular=celular
    def setCelular(self,celular):
        self.celular=celular
    def getNombre(self):
        return self.nombre
    def cantar(self,orquesta):
        msg="EL voaclista {} con muchos exitos con las mejores {} trabaja en orquesta {}  "
        return msg.format(self.nombre,self.musicas,orquesta)

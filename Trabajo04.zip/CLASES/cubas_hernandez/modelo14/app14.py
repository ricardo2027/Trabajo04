import orquesta
import vocalista
import os
nom=os.sys.argv[1]
nombre=os.sys.argv[2]


orque=orquesta.Orquesta(nom,"vocalista","num_musicos","origen",233454)
vocal=vocalista.Vocalista(nombre,"musica","orquesta","gmail",977665433)

#hacemos la relacion de ambas clases


a=vocal.cantar(orque.getNombre())
print(a)
